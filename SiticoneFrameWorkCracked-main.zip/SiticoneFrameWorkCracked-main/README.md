# SiticoneFrameWorkCracked
Siticone.Desktop.UI Cracked by Cabbo. Latest version: 11/11/2022

# Crack

Latest Siticone.Desktop.UI FrameWork version cracked. Working as 11/11/2022, and tested with .NET FrameWork 4.8.1.

# How to use it
Replace the new Siticone.Desktop.UI.DLL in your Directory: ProjectName\packages\Siticone.Desktop.UI.2.1.1\lib\net40\Siticone.Desktop.UI.DLL

Enjoy.

# Do you want to contact me?
Discord: FreeCabbo10#6558

Telegram: https://t.me/cabboshiba
